import { Routes, Route, Link } from 'react-router-dom'
import Navbar from './components/Navbar'
import AboutUs from './components/AboutUs'
import ProductList from './components/ProductList'
import CartItem from './components/CartItem'

function LandingPage() {
  return (
    <main className="hero">
      <div className="hero-overlay">
        <div className="hero-content">
          <p className="eyebrow">BRING NATURE HOME</p>
          <h1>Paradise Nursery</h1>
          <p className="hero-subtitle">A little green makes a big difference.</p>
          <p className="hero-description">Discover indoor plants that bring freshness, calm, and life to every corner of your home.</p>
          <Link className="primary-button" to="/products">Get Started</Link>
          <Link className="hero-about" to="/about">Learn more about us</Link>
        </div>
      </div>
    </main>
  )
}

export default function App() {
  return (
    <div className="app-shell">
      <Navbar />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/products" element={<ProductList />} />
        <Route path="/cart" element={<CartItem />} />
        <Route path="*" element={<LandingPage />} />
      </Routes>
      <footer className="footer">© 2026 Paradise Nursery. Grow something beautiful.</footer>
    </div>
  )
}