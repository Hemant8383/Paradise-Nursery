import { useDispatch, useSelector } from 'react-redux'
import { addItem } from '../features/CartSlice'
import { plants } from '../data/plants'

export default function ProductList() {
  const dispatch = useDispatch()
  const cartItems = useSelector(state => state.cart.items)
  const categories = [...new Set(plants.map(plant => plant.category))]

  return (
    <main className="catalog-page">
      <header className="page-heading">
        <p className="eyebrow">FIND YOUR GREEN COMPANION</p>
        <h1>Our Plant Collection</h1>
        <p>Choose your favourites and bring a fresh feel to your space.</p>
      </header>
      {categories.map(category => (
        <section className="plant-category" key={category}>
          <h2>{category}</h2>
          <div className="plant-grid">
            {plants.filter(plant => plant.category === category).map(plant => {
              const added = cartItems.some(item => item.id === plant.id)
              return (
                <article className="plant-card" key={plant.id}>
                  <img src={plant.image} alt={plant.name} />
                  <div className="plant-info">
                    <h3>{plant.name}</h3>
                    <p>{plant.description}</p>
                    <div className="plant-card-bottom">
                      <strong>₹{plant.price}</strong>
                      <button disabled={added} onClick={() => dispatch(addItem(plant))}>
                        {added ? 'Added' : 'Add to Cart'}
                      </button>
                    </div>
                  </div>
                </article>
              )
            })}
          </div>
        </section>
      ))}
    </main>
  )
}