import { Link } from 'react-router-dom'

export default function AboutUs() {
  return (
    <main className="about-page">
      <section className="about-card">
        <p className="eyebrow">GROW WITH US</p>
        <h1>About Paradise Nursery</h1>
        <p>At Paradise Nursery, we believe every space feels better with a little greenery. Our goal is to make bringing nature home simple, joyful, and affordable.</p>
        <p>We carefully select beautiful indoor plants for homes, study spaces, and offices. Whether you are a new plant parent or a gardening enthusiast, we help you find a plant that fits your space and lifestyle.</p>
        <p>Thank you for choosing us to make your surroundings greener, calmer, and more beautiful.</p>
        <Link className="primary-button" to="/products">Explore Plants</Link>
      </section>
    </main>
  )
}