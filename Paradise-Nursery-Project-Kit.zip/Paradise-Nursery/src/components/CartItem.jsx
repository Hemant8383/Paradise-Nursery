import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { removeItem, updateQuantity } from '../features/CartSlice'

export default function CartItem() {
  const dispatch = useDispatch()
  const items = useSelector(state => state.cart.items)
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <main className="cart-page">
      <header className="page-heading">
        <p className="eyebrow">YOUR SELECTED GREENS</p>
        <h1>Shopping Cart</h1>
      </header>
      {items.length === 0 ? (
        <section className="empty-cart">
          <div className="empty-icon">🪴</div>
          <h2>Your cart is waiting for some green!</h2>
          <p>Explore our collection and choose your favourite plants.</p>
          <Link className="primary-button" to="/products">Continue Shopping</Link>
        </section>
      ) : (
        <>
          <section className="cart-list">
            {items.map(item => (
              <article className="cart-row" key={item.id}>
                <img src={item.image} alt={item.name} />
                <div className="cart-product">
                  <h3>{item.name}</h3>
                  <p>₹{item.price} each</p>
                  <button className="remove-button" onClick={() => dispatch(removeItem(item.id))}>Remove</button>
                </div>
                <div className="quantity-control">
                  <button aria-label={`Decrease ${item.name}`} onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity - 1 }))}>−</button>
                  <span>{item.quantity}</span>
                  <button aria-label={`Increase ${item.name}`} onClick={() => dispatch(updateQuantity({ id: item.id, quantity: item.quantity + 1 }))}>+</button>
                </div>
                <strong className="line-total">₹{item.price * item.quantity}</strong>
              </article>
            ))}
          </section>
          <section className="cart-summary">
            <Link className="text-link" to="/products">← Continue Shopping</Link>
            <div className="summary-total"><span>Total Amount</span><strong>₹{total}</strong></div>
            <button className="checkout-button" onClick={() => window.alert('Coming Soon! Thank you for shopping with Paradise Nursery.')}>Checkout</button>
          </section>
        </>
      )}
    </main>
  )
}