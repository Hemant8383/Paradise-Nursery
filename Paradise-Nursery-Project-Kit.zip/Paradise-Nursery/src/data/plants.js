const photo = (id) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=700&q=80`

export const plants = [
  { id: 1, name: 'Monstera Deliciosa', category: 'Air Purifying', price: 599, description: 'A tropical beauty with iconic split leaves.', image: photo('photo-1614594975525-e45190c55d0b') },
  { id: 2, name: 'Snake Plant', category: 'Air Purifying', price: 399, description: 'A hardy plant that is easy to care for.', image: photo('photo-1593691509543-c55fb32e5cee') },
  { id: 3, name: 'Peace Lily', category: 'Air Purifying', price: 499, description: 'Elegant white blooms and deep green leaves.', image: photo('photo-1593691509543-c55fb32e5cee') },
  { id: 4, name: 'Areca Palm', category: 'Air Purifying', price: 699, description: 'A graceful palm that adds a tropical touch.', image: photo('photo-1512428813834-c702c7702b78') },
  { id: 5, name: 'Spider Plant', category: 'Air Purifying', price: 299, description: 'A cheerful, beginner-friendly hanging plant.', image: photo('photo-1572688484438-313a6e50c333') },
  { id: 6, name: 'Rubber Plant', category: 'Air Purifying', price: 549, description: 'Glossy leaves make a bold statement.', image: photo('photo-1501004318641-b39e6451bec6') },
  { id: 7, name: 'Jade Plant', category: 'Succulents', price: 249, description: 'A compact succulent with rounded leaves.', image: photo('photo-1509423350716-97f9360b4e09') },
  { id: 8, name: 'Echeveria', category: 'Succulents', price: 199, description: 'A beautiful rosette-shaped succulent.', image: photo('photo-1485955900006-10f4d324d411') },
  { id: 9, name: 'Aloe Vera', category: 'Succulents', price: 279, description: 'A useful succulent with fleshy green leaves.', image: photo('photo-1509423350716-97f9360b4e09') },
  { id: 10, name: 'Haworthia', category: 'Succulents', price: 229, description: 'A small sculptural plant for sunny desks.', image: photo('photo-1485955900006-10f4d324d411') },
  { id: 11, name: 'String of Pearls', category: 'Succulents', price: 349, description: 'Trailing stems dotted with bead-like leaves.', image: photo('photo-1459411552884-841db9b3cc2a') },
  { id: 12, name: 'Zebra Cactus', category: 'Succulents', price: 259, description: 'A striking little plant with striped leaves.', image: photo('photo-1509423350716-97f9360b4e09') },
  { id: 13, name: 'Golden Pothos', category: 'Hanging Plants', price: 329, description: 'A fast-growing vine with golden patterns.', image: photo('photo-1497250681960-ef046c08a56e') },
  { id: 14, name: 'English Ivy', category: 'Hanging Plants', price: 379, description: 'Classic trailing foliage for shelves and baskets.', image: photo('photo-1463936575829-25148e1d8?auto=format&fit=crop&w=700&q=80') },
  { id: 15, name: 'Heartleaf Philodendron', category: 'Hanging Plants', price: 399, description: 'Heart-shaped leaves on graceful trailing vines.', image: photo('photo-1509423350716-97f9360b4e09') },
  { id: 16, name: 'String of Hearts', category: 'Hanging Plants', price: 449, description: 'Delicate heart-shaped leaves on fine stems.', image: photo('photo-1459411552884-841db9b3cc2a') },
  { id: 17, name: 'Boston Fern', category: 'Hanging Plants', price: 429, description: 'Soft, feathery fronds create a lush display.', image: photo('photo-1518531933037-91b2f5f229cc') },
  { id: 18, name: 'Burro’s Tail', category: 'Hanging Plants', price: 499, description: 'Plump cascading leaves for a sunny corner.', image: photo('photo-1485955900006-10f4d324d411') }
]